package com.stackroute.service;

import com.stackroute.exception.BlogAlreadyExistsException;
import com.stackroute.exception.BlogNotFoundException;
import com.stackroute.domain.Blog;
import com.stackroute.repository.BlogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import java.util.List;
import java.util.Optional;
/* This is ServiceImplementation Class which should implement BlogService Interface and override all the implemented methods.
 * Handle suitable exceptions for all the implemented methods*/

@Service
@Transactional
public class BlogServiceImpl implements BlogService {


    private BlogRepository blogRepository;

    /**
     * Constructor based Dependency injection to inject BlogRepository here
     */
    @Autowired
    public BlogServiceImpl(BlogRepository blogRepository) {
        this.blogRepository = blogRepository;
    }


    @Override
    public Blog saveBlog(Blog blog) throws BlogAlreadyExistsException {
        if(blogRepository.existsById(blog.getBlogId())){
            throw new BlogAlreadyExistsException("Blog Already Exists");
        }else{
            return blogRepository.save(blog);
        }


    }

    @Override
    public List<Blog> getAllBlogs() {
//        List<Blog> list=new ArrayList<>();
//        blogRepository.findAll().forEach(blog -> list.add(blog));
//        if(list.isEmpty()){
//            return null;
//        }
//        return list;

        List<Blog> blogs = (List<Blog>) blogRepository.findAll();
        return blogs;
    }

    @Override
    public Blog getBlogById(int id) throws BlogNotFoundException {
       Optional<Blog> blog=blogRepository.findById(id);
       Optional<Blog> blog2=blogRepository.findById(id);
       if(blog.isEmpty()){
           throw new BlogNotFoundException("Blog Not Found");
       }else{
           return blog.get();
       }
    }

    @Override
    public Blog deleteBlog(int id) throws BlogNotFoundException {
        Optional<Blog> blog= blogRepository.findById(id);
        Optional<Blog> blog2= blogRepository.findById(id);
        if(blog.isPresent()){
            blogRepository.deleteById(id);
            return blog.get();
        }else{
            throw new BlogNotFoundException("Blog Not Found");
        }

    }

    @Override
    public Blog updateBlog(Blog blog) throws BlogNotFoundException {
        //Optional<Blog> blog1 = blogRepository.findById(blog.getBlogId());
        if(blogRepository.existsById(blog.getBlogId())){
            return blogRepository.save(blog);
        }else{
            throw new BlogNotFoundException("Blog Not Found");
        }


    }
}

